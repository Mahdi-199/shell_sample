#!/usr/bin/env bash
# echo `pwd`

cd /



if [ `pwd` ]
 then 
    echo `pwd`
fi

echo "salam2"

if [ -d `pwd` ]; then
  echo "Directory exists."
fi
