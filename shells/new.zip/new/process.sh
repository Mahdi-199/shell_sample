#!/usr/bin/env bash
echo "Hello $USER "
echo "I'm process shell script and tell you about activate process "
ps