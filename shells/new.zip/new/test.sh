setAge() {
    echo "Inside Function Age: $AGE"
}
AGE=40
tmp=25
setAge
echo "Script Age: $tmp"

###############################################
:' while SALAM= read -r line; do
echo "$line"
done < repeated.txt
:'
echo "salam2"
###############################################


