#!/usr/bin/env bash
echo "hey what's your name?"
read a 
echo "Nice to meet you $a, would you like to tell me last name?"
read b
echo "thanks Mr/Mis. $a $b for telling me your name"
echo "It's time to say you good bye!"

