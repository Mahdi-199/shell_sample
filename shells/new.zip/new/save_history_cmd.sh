#!/usr/bin/env bash
echo "Hello $USER"

history > 
