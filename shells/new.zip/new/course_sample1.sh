#!/usr/bin/env bash
num1=5
num2=10
num3=100
num4=20

if [ $num1 -lt $num2 ]
then
    echo "Condition is Correct"
fi

######################################